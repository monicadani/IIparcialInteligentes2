# IIparcialInteligentes2
Parcial donde se desarrolla un agente inteligente capaz de extraer y sumar los valores numéricos que están representados en las cartas españolas con categoría de 6 a 12.
